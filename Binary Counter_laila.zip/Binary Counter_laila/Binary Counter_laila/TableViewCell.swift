//
//  TableViewCell.swift
//  Binary Counter_laila
//
//  Created by administrator on 11/12/2021.
//

import UIKit

protocol CountDelegate {
    
    func Pluse(number:String)
    func Minuse(number:String)
}

class TableViewCell: UITableViewCell {
    
    @IBOutlet var NumberLaber: UILabel!
    
    var delegate: CountDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func MinusButton(_ sender: UIButton) {
        
        delegate?.Minuse(number: (self.NumberLaber?.text)!)
        
    }
    
    @IBAction func PluseButton(_ sender: UIButton) {
        
        delegate?.Pluse(number: (self.NumberLaber?.text)!)
        
    }
    
}
