//
//  ViewController.swift
//  Binary Counter_laila
//
//  Created by administrator on 11/12/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var Table: UITableView!
    @IBOutlet var TotalLabel: UILabel!
    
    var total =  0
    var Numbers = [1,10,100,1000,10000,100000,1000000,10000000,100000000,1000000000,10000000000,100000000000,1000000000000,10000000000000]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        Table.dataSource = self
        
    }

    
}


extension ViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Numbers.count
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCalls") as! TableViewCell
         
         cell.NumberLaber?.text = String(Numbers[indexPath.row])
         cell.delegate = self
        
        return cell
        
    }
    
}

extension ViewController:CountDelegate
{
    func Pluse(number: String) {
   
        total = total + (Int(number))!
        TotalLabel.text = "\(total)"
        
    }
    
    func Minuse(number: String) {
        
             total = total - (Int(number))!
             TotalLabel.text = "\(total)"
    }
}
