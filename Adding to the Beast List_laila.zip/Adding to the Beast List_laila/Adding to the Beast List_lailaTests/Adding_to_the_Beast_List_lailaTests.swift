//
//  Adding_to_the_Beast_List_lailaTests.swift
//  Adding to the Beast List_lailaTests
//
//  Created by administrator on 08/12/2021.
//

import XCTest
@testable import Adding_to_the_Beast_List_laila

class Adding_to_the_Beast_List_lailaTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
