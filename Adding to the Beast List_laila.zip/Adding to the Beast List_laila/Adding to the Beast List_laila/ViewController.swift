//
//  ViewController.swift
//  Adding to the Beast List_laila
//
//  Created by administrator on 08/12/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textfield: UITextField!
    @IBOutlet weak var table: UITableView!
    
    var list = ["Sleep", "Coding", "Eating", "Playing"]
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        table.dataSource = self
        table.delegate = self
        
    }

    @IBAction func beastButtonPressed(_ sender: UIButton) {
        
        guard let task = textfield.text else{return}
        if !list.isEmpty{
            list.append(task)
            table.reloadData()
            textfield.text=""
        }
    }
    
}

extension ViewController: UITableViewDataSource , UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return an integer that indicates how many rows (cells) to draw
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCalls", for: indexPath)
        cell.textLabel?.text = list[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        list.remove(at: indexPath.row)
        tableView.reloadData()
    }
}
