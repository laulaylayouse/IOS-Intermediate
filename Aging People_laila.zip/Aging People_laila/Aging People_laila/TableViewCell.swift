//
//  TableViewCell.swift
//  Aging People_laila
//
//  Created by administrator on 09/12/2021.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var age: UILabel!
    @IBOutlet var Name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
