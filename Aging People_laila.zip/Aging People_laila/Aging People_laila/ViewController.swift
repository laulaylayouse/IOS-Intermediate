//
//  ViewController.swift
//  Aging People_laila
//
//  Created by administrator on 09/12/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    
    let names = ["Laila","Lolo","Sara","Manal","Zainzb","Ali"
               ,"Hassan","Yousef","Mona","Raza","Mya","Syfa"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        table.dataSource = self
    }


}

extension ViewController: UITableViewDataSource {
    //Datasource
    // How many cells are we going to need?
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return an integer that indicates how many rows (cells) to draw
        return names.count
    }
    
    // How should I create each cell?
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCalls", for: indexPath) as! TableViewCell
        
        cell.Name?.text = names[indexPath.row]
        cell.age?.text = "\(Int.random(in: 5...95)) years old"
    
        return cell
    }
    
    
    
}

